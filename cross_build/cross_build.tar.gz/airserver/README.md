This is a temp solution for putting airserver in OpenWRT on the raspberry pi. 
We are currently in the process of making a package for OpenWRT.