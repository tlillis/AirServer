set -x #echo commands

tar xzf airserver.tar.gz
cp -r lib/* /usr/lib
